# utils

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test utils` to execute the unit tests via [Jest](https://jestjs.io).

## Running lint

Run `nx lint utils` to execute the lint via [ESLint](https://eslint.org/).

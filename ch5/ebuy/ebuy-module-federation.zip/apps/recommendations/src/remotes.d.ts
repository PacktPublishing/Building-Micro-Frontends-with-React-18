// Declare your remote Modules here
// Example declare module 'about/Module';
declare module 'catalog/Module';
declare module 'checkout/Module';
declare module 'store/Module';

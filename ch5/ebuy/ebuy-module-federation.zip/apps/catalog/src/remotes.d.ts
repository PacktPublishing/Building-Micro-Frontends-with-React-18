// Declare your remote Modules here
// Example declare module 'about/Module';
declare module 'recommendations/Module';
